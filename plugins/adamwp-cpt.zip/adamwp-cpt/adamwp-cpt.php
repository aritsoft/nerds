<?php
/*
Plugin Name: Adam Post Types & Taxonomies
Version: 1.0
Plugin URI: https://www.cxwebexperts.com
Description: Creates Portfolio Post Portfolio Category and Taxonomy
Author: CXWebExperts
Author URI: https://www.cxwebexperts.com
Text Domain: adamwpcpt
*/

register_activation_hook( __FILE__,  'adamwp_activated' );

add_action( 'init', 'adamwp_custom_post_type', 0 );
add_action( 'init', 'adamwp_custom_taxonomy', 0 );

function adamwp_activated() {

    flush_rewrite_rules();
    
}


// Register Custom Post Portfolio Category
function adamwp_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Portfolios', 'Post Portfolio Category General Name', 'adamwpcpt' ),
		'singular_name'         => _x( 'Portfo', 'Post Portfolio Category Singular Name', 'adamwpcpt' ),
		'menu_name'             => __( 'Portfolios', 'adamwpcpt' ),
		'name_admin_bar'        => __( 'Post Portfolio Category', 'adamwpcpt' ),
		'archives'              => __( 'Item Archives', 'adamwpcpt' ),
		'attributes'            => __( 'Item Attributes', 'adamwpcpt' ),
		'parent_item_colon'     => __( 'Parent Item:', 'adamwpcpt' ),
		'all_items'             => __( 'All Items', 'adamwpcpt' ),
		'add_new_item'          => __( 'Add New Item', 'adamwpcpt' ),
		'add_new'               => __( 'Add New', 'adamwpcpt' ),
		'new_item'              => __( 'New Item', 'adamwpcpt' ),
		'edit_item'             => __( 'Edit Item', 'adamwpcpt' ),
		'update_item'           => __( 'Update Item', 'adamwpcpt' ),
		'view_item'             => __( 'View Item', 'adamwpcpt' ),
		'view_items'            => __( 'View Items', 'adamwpcpt' ),
		'search_items'          => __( 'Search Item', 'adamwpcpt' ),
		'not_found'             => __( 'Not found', 'adamwpcpt' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'adamwpcpt' ),
		'featured_image'        => __( 'Featured Image', 'adamwpcpt' ),
		'set_featured_image'    => __( 'Set featured image', 'adamwpcpt' ),
		'remove_featured_image' => __( 'Remove featured image', 'adamwpcpt' ),
		'use_featured_image'    => __( 'Use as featured image', 'adamwpcpt' ),
		'insert_into_item'      => __( 'Insert into item', 'adamwpcpt' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'adamwpcpt' ),
		'items_list'            => __( 'Items list', 'adamwpcpt' ),
		'items_list_navigation' => __( 'Items list navigation', 'adamwpcpt' ),
		'filter_items_list'     => __( 'Filter items list', 'adamwpcpt' ),
	);
	$args = array(
		'label'                 => __( 'Portfolio', 'adamwpcpt' ),
		'description'           => __( 'Post Portfolio Category Description', 'adamwpcpt' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',

	);
	register_post_type( 'portfolio', $args );

}


// Register Custom Taxonomy
function adamwp_custom_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Portfolio Categories', 'Taxonomy General Name', 'adamwpcpt' ),
		'singular_name'              => _x( 'Portfolio Category', 'Taxonomy Singular Name', 'adamwpcpt' ),
		'menu_name'                  => __( 'Portfolio Category', 'adamwpcpt' ),
		'all_items'                  => __( 'All Items', 'adamwpcpt' ),
		'parent_item'                => __( 'Parent Item', 'adamwpcpt' ),
		'parent_item_colon'          => __( 'Parent Item:', 'adamwpcpt' ),
		'new_item_name'              => __( 'New Item Name', 'adamwpcpt' ),
		'add_new_item'               => __( 'Add New Item', 'adamwpcpt' ),
		'edit_item'                  => __( 'Edit Item', 'adamwpcpt' ),
		'update_item'                => __( 'Update Item', 'adamwpcpt' ),
		'view_item'                  => __( 'View Item', 'adamwpcpt' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'adamwpcpt' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'adamwpcpt' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'adamwpcpt' ),
		'popular_items'              => __( 'Popular Items', 'adamwpcpt' ),
		'search_items'               => __( 'Search Items', 'adamwpcpt' ),
		'not_found'                  => __( 'Not Found', 'adamwpcpt' ),
		'no_terms'                   => __( 'No items', 'adamwpcpt' ),
		'items_list'                 => __( 'Items list', 'adamwpcpt' ),
		'items_list_navigation'      => __( 'Items list navigation', 'adamwpcpt' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'portfolio_category', array( 'portfolio' ), $args );

	}
